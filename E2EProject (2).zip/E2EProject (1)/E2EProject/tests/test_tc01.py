import time

from pages.HomePage import HomePage
from utilities.BaseClass import BaseClass


class TestCase_01(BaseClass):
    def test_testcase_01(self):
        home_page = HomePage(self.driver)
        checkout_page = home_page.shop_items()
        checkout_page.select_item()
        checkout_page.click_checkout_link()
        # time.sleep(2)
        confirmation_page = checkout_page.checkout_items()
        # time.sleep(4)
        confirmation_page.select_country()
        confirmation_page.click_terms_and_conditions_checkbox()
        confirmation_page.click_purchase_button()
        self.wait_for_element_to_be_visible(confirmation_page.success_message)
        confirmation_page.verify_success_message()
        time.sleep(4)
        # print(self.driver.title)
        # print(self.driver.current_url)
