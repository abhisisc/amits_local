import time
import pytest
from pages.HomePage import HomePage
from utilities.BaseClass import BaseClass


@pytest.mark.usefixtures("get_data")
class TestCase_02(BaseClass):
    def test_testcase_02(self, get_data):
        self.driver.get("https://rahulshettyacademy.com/angularpractice/")
        home_page = HomePage(self.driver)
        home_page.type_name(get_data[0])
        home_page.type_email(get_data[1])
        self.select_dropdown_using_visible_text(get_data[2], home_page.get_gender_dropdown())
        time.sleep(10)
        home_page.click_submit_button()
        self.wait_for_element_to_presence(home_page.success_message)
        home_page.verify_success_message()
