import time
import pytest
from pages.HomePage import HomePage
from utilities.BaseClass import BaseClass


# test data from excel
@pytest.mark.usefixtures("get_data_using_excel")
class TestCase_05(BaseClass):
    def test_testcase_05(self, get_data_using_excel):
        self.driver.get("https://rahulshettyacademy.com/angularpractice/")
        home_page = HomePage(self.driver)
        home_page.type_name(get_data_using_excel["Name"])
        home_page.type_email(get_data_using_excel["eMail"])
        self.select_dropdown_using_visible_text(get_data_using_excel["Gender"], home_page.get_gender_dropdown())
        time.sleep(10)
        home_page.click_submit_button()
        self.wait_for_element_to_presence(home_page.success_message)
        home_page.verify_success_message()
