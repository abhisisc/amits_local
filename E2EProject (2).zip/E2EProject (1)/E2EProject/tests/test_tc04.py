import time
import pytest
from pages.HomePage import HomePage
from utilities.BaseClass import BaseClass


# test data from another python file
from utilities.TestData import TestData


@pytest.mark.usefixtures("get_data_from_python_file_using_dictionary")
class TestCase_04(BaseClass):
    def test_testcase_04(self, get_data_from_python_file_using_dictionary):
        log = self.get_logger()
        self.driver.get("https://rahulshettyacademy.com/angularpractice/")
        home_page = HomePage(self.driver)
        home_page.type_name(get_data_from_python_file_using_dictionary["firstName"])
        log.info("Enter the first name" + get_data_from_python_file_using_dictionary["firstName"])
        home_page.type_email(get_data_from_python_file_using_dictionary["lastName"])
        log.info("Enter the last name" + get_data_from_python_file_using_dictionary["lastName"])
        self.select_dropdown_using_visible_text(get_data_from_python_file_using_dictionary["gender"],
                                                home_page.get_gender_dropdown())
        time.sleep(10)
        log.info("Select the gender" + get_data_from_python_file_using_dictionary["gender"])
        home_page.click_submit_button()
        self.wait_for_element_to_presence(home_page.success_message)
        home_page.verify_success_message()


# test data from another python file
@pytest.fixture(params=TestData.home_page_testdata)
def get_data_from_python_file_using_dictionary(request):
    return request.param
