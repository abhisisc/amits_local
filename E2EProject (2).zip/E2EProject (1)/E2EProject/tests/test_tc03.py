import time
import pytest
from pages.HomePage import HomePage
from utilities.BaseClass import BaseClass


# test data within the same fixture
@pytest.mark.usefixtures("get_data_using_dictionary")
class TestCase_03(BaseClass):
    def test_testcase_03(self, get_data_using_dictionary):
        self.driver.get("https://rahulshettyacademy.com/angularpractice/")
        home_page = HomePage(self.driver)
        home_page.type_name(get_data_using_dictionary["firstName"])
        home_page.type_email(get_data_using_dictionary["lastName"])
        self.select_dropdown_using_visible_text(get_data_using_dictionary["gender"], home_page.get_gender_dropdown())
        time.sleep(10)
        home_page.click_submit_button()
        self.wait_for_element_to_presence(home_page.success_message)
        home_page.verify_success_message()
