import openpyxl

dictionary = {}
data_list = []
print("Load the Excel")
workbook = openpyxl.load_workbook("C:/Users/lpunyam/OneDrive - Capgemini/Desktop/Python_Workspace/E2EProject/resources/test_data.xlsx")
sheet = workbook.get_sheet_by_name("Data_01")
for i in range(2, sheet.max_row + 1):
    dic = {}
    for j in range(2, sheet.max_column + 1):
        dictionary[sheet.cell(row=1, column=j).value] = sheet.cell(row=i, column=j).value
        dic = dictionary.copy()
    data_list.append(dic)
print(data_list)