import openpyxl
import pytest


class TestData:
    home_page_testdata = [{"firstName": "Chanti", "lastName": "Chanti@mail.com", "gender": "Female"},
                          {"firstName": "Chinni", "lastName": "Chinni@mail.com", "gender": "Male"},
                          {"firstName": "Lucky", "lastName": "LuckyChinni@mail.com", "gender": "Female"}]

    @staticmethod
    def excel_read():
        dictionary = {}
        data_list = []
        print("Load the Excel")
        workbook = openpyxl.load_workbook(
            "C:/Users/lpunyam/OneDrive - Capgemini/Desktop/Python_Workspace/E2EProject/resources/test_data.xlsx")
        sheet = workbook.get_sheet_by_name("Data_01")
        for i in range(2, sheet.max_row + 1):
            dic_copy = {}
            for j in range(2, sheet.max_column + 1):
                dictionary[sheet.cell(row=1, column=j).value] = sheet.cell(row=i, column=j).value
                dic_copy = dictionary.copy()
            data_list.append(dic_copy)
        return data_list
