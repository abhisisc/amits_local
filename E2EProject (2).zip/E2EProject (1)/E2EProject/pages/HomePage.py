from selenium.webdriver.common.by import By

from pages.CheckoutPage import CheckoutPage


class HomePage:
    shop_link = (By.XPATH, "//a[contains(.,'Shop')]")
    name_textbox = (By.XPATH, "//input[@name='name']")
    email_textbox = (By.XPATH, "//input[@name='email']")
    gender_dropdown = (By.XPATH, "//select[@class='form-control']")
    submit_button = (By.XPATH, "//input[@type='submit']")
    success_message = (By.XPATH, "//*[contains(@class,'alert-success')]")

    def __init__(self, driver):
        self.driver = driver

    def shop_items(self):
        self.driver.find_element(*HomePage.shop_link).click()
        checkout_page = CheckoutPage(self.driver)
        return checkout_page

    def type_name(self, name):
        self.driver.find_element(*HomePage.name_textbox).send_keys(name)

    def type_email(self, email):
        self.driver.find_element(*HomePage.email_textbox).send_keys(email)

    def get_gender_dropdown(self):
        return self.driver.find_element(*HomePage.gender_dropdown)

    def click_submit_button(self):
        self.driver.find_element(*HomePage.submit_button).click()

    def verify_success_message(self):
        message_value = self.driver.find_element(*HomePage.success_message).text
        if "Success" in message_value:
            print("Form submitted successfully !!")
        else:
            print("Form not submitted !!")
