import time

from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions
from selenium.webdriver.support.wait import WebDriverWait


class ConfirmationPage:
    country_textbox = (By.XPATH, "//input[@id='country']")
    country_suggestions_list = (By.XPATH, "//*[@class='suggestions']")
    country_list = (By.XPATH, "//*[@class='suggestions']//a")
    terms_and_conditions_checkbox = (By.XPATH, "//label[contains(.,'I agree with the term & Conditions')]")
    success_message = (By.XPATH, "//*[contains(@class,'alert-success')]")
    purchase_button = (By.XPATH, "//input[@value='Purchase']")

    def __init__(self, driver):
        self.driver = driver

    def select_country(self):
        country_name = "In"
        self.driver.find_element(*ConfirmationPage.country_textbox).send_keys(country_name)
        element = WebDriverWait(self.driver, 20).until(
            expected_conditions.presence_of_element_located((By.XPATH, "//*[@class='suggestions']")))

        country_list = self.driver.find_elements(*ConfirmationPage.country_list)

        for country in country_list:
            country_value = country.text
            if country_value == "India":
                country.click()
                break

    def click_terms_and_conditions_checkbox(self):
        element = self.driver.find_element(*ConfirmationPage.terms_and_conditions_checkbox)
        status = element.is_selected()
        if not status:
            element.click()

    def click_purchase_button(self):
        self.driver.find_element(*ConfirmationPage.purchase_button).click()

    def verify_success_message(self):
        message_value = self.driver.find_element(*ConfirmationPage.success_message).text
        if "Success" in message_value:
            print("Item ordered successfully !!")
        else:
            print("Item not ordered !!")
