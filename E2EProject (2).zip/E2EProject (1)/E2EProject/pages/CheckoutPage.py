import time

from selenium.webdriver.common.by import By

from pages.ConfirmationPage import ConfirmationPage


class CheckoutPage:
    items_list = (By.XPATH, "//*[@class='card-title']/a")
    add_button = (By.XPATH, "//button[contains(.,'Add')]")
    checkout_link = (By.XPATH, "//a[contains(.,'Checkout')]")
    checkout_button = (By.XPATH, "//button[contains(.,'Checkout')]")

    def __init__(self, driver):
        self.driver = driver

    def get_items_list(self):
        return self.driver.find_elements(*CheckoutPage.items_list)

    def select_item(self):
        items_list = self.driver.find_elements(*CheckoutPage.items_list)
        for item in items_list:
            item_value = item.text
            # print(item_value)
            if item_value == "Blackberry":
                item.find_element(*CheckoutPage.add_button).click()
                time.sleep(5)
                break

    def click_checkout_link(self):
        self.driver.find_element(*CheckoutPage.checkout_link).click()

    def checkout_items(self):
        self.driver.find_element(*CheckoutPage.checkout_button).click()
        confirmation_page = ConfirmationPage(self.driver)
        return confirmation_page
